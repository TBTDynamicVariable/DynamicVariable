package com.kevry.math;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //et = (EditText)findViewById(R.id.editText) ;

        // Example of a call to a native method
        TextView tv = (TextView) findViewById(R.id.sample_text);
        tv.setText(stringFromJNI());
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();


    public void generate(View view) {

        float check, rnd;
        char[] operations = {'+','-','*','/'};

        Random rand = new Random();
        int num = rand.nextInt(15);
        int num1 = rand.nextInt(15);
        int op = rand.nextInt(4);
        int result=0;

        if (op==3)
        {
          check = (float)num/num1;
          rnd = Math.round(check);

            while ((check!=rnd) || (num1==0))
            {
                num = rand.nextInt(2);
                num1 = rand.nextInt(2);
                check=(float)num/num1;
                rnd = Math.round(check);
            }
        }

        switch(op)
        {
            case 0:
                result = num+num1;
                break;

            case 1:
                result = num-num1;
                break;

            case 2:
                result = num*num1;
                break;

            case 3:
                result = num/num1;
                break;
        }

        TextView myText = (TextView)findViewById(R.id.sample_text);

        String myString1 = String.valueOf(num1);
        String myString = String.valueOf(num);

        myText.setText(myString + operations[op] + myString1+"=");

        EditText edit = (EditText)findViewById(R.id.editText);
        String text = edit.getText().toString();


        String MyStrres = String.valueOf(result);

        TextView answer = (TextView)findViewById(R.id.textView);
        if (MyStrres==text)
            answer.setText("Correct");
        else
            answer.setText("Wrong");



    }




}


