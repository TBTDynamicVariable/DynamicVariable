package com.wordpress.mentalhealthmonitor.dynamicvariable;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.ArrayList;

public class Leaderboard extends AppCompatActivity {



    TextView first;
    TextView second;
    TextView third;
    TextView fourth;
    TextView fifth;
    TextView sixth;
    TextView seventh;
    TextView eighth;
    TextView ninth;
    TextView tenth;



    private Button toMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);
        toMain = (Button) findViewById(R.id.mainButLeader);

        readfile();

        toMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMain();
            }
        });
    }
    public void openMain(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void readfile(){
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = openFileInput("HighScoreL.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);

            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuffer stringBuffer = new StringBuffer();

            List<String> scores = new ArrayList<String>();
            String line = null;

            while ((line = bufferedReader.readLine()) != null) {
               scores.add(line);
            }

            first  = (TextView) findViewById(R.id.place1);
            second  = (TextView) findViewById(R.id.place2);
            third  = (TextView) findViewById(R.id.place3);
            fourth  = (TextView) findViewById(R.id.place4);
            fifth  = (TextView) findViewById(R.id.place5);
            sixth  = (TextView) findViewById(R.id.place6);
            seventh  = (TextView) findViewById(R.id.place7);
            eighth  = (TextView) findViewById(R.id.place8);
            ninth  = (TextView) findViewById(R.id.place9);
            tenth  = (TextView) findViewById(R.id.place10);
            first.setText(scores.get(0));
            second.setText(scores.get(1));
            third.setText(scores.get(2));
            fourth.setText(scores.get(3));
            fifth.setText(scores.get(4));
            sixth.setText(scores.get(5));
            seventh.setText(scores.get(6));
            eighth.setText(scores.get(7));
            ninth.setText(scores.get(8));
            tenth.setText(scores.get(9));



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
