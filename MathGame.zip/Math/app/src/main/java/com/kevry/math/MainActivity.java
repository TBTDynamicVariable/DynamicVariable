package com.kevry.math;

import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.CountDownTimer;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.widget.ImageView;
import android.widget.ImageButton;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    //static {
    //   System.loadLibrary("native-lib");
    //}

    int counter; //Number of correct answers after timer ends

    private Button b1;
    private Button b2;
    TextView t1;
    TextView t2;
    EditText e1;


    int answer;
    int result;
    int flag;

    TextView timerTextView;
    private CountDownTimer countDownTimer;
    private long timeRemaining = 60000; //1 min
    private boolean timerRunning;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        e1 = (EditText) findViewById(R.id.editText);
        t1 = (TextView) findViewById(R.id.sample_text);
        t2 = (TextView) findViewById(R.id.textView);
        b2 = ((Button) findViewById(R.id.restart));

        timerTextView = (TextView) findViewById(R.id.timerTextView);
        b1 = (Button) findViewById(R.id.button);


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Testing", Snackbar.LENGTH_LONG) .setAction("Action", null).show();
            }
        });



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GenerateEq();
                startStop();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter=0;
                GenerateEq();
             countDownTimer.cancel();
             countDownTimer.start();
            }
        });


        updateTimer();
        EnterValue();


        // Example of a call to a native method
        //TextView tv = (TextView) findViewById(R.id.sample_text);
        //tv.setText(stringFromJNI());
    }

    public void startStop()
    {
        if (timerRunning){
            stopTimer();
        } else {
            startTimer();
        }
    }

    public void startTimer() {
      countDownTimer=new CountDownTimer(timeRemaining,1000) {
      @Override
      public void onTick(long l) {
          timeRemaining=l;
          updateTimer();
      }

      @Override
      public void onFinish() {
       t1.setText("YOU GOT " + String.valueOf(counter) + " PTS");
       t2.setText("");
      }
    }.start();


  b1.setText("PAUSE");
  timerRunning=true;
    }

    public void stopTimer(){
        b1.setText("START");
        countDownTimer.cancel();
        timerRunning=false;
    }

    public void updateTimer(){
        int minutes = (int)timeRemaining/60000;
        int seconds = (int) timeRemaining%60000 /1000;

        String timeLeft;

        timeLeft = "" + minutes;
        timeLeft += ":";

        if (seconds<10) timeLeft+="0";
        timeLeft+=seconds;

        timerTextView.setText(timeLeft);
    }



  private void EnterValue() {
        e1.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {


                String ans = e1.getText().toString();
                answer = Integer.parseInt(ans);

                if (answer==result){
                    t2.setText("CORRECT");
                    e1.setText(null);
                    GenerateEq();
                    counter++;
                    //flag=0;
                }

                else {
                    t2.setText("INCORRECT! Try Again");
                    e1.setText(null);
                    //flag=1;
                }
                    return true;
            }

                    return false;
                }
       });

    }




    private void GenerateEq() {

                int first=0, finale;
                float check, rnd, check1, rnd1;
                char[] operations = {'+', '-', '*', '/'};

                Random rand = new Random();
                int num;
                int num1;
                int num2;

                int op;
                int op1;

                do {

                    num = rand.nextInt(12) + 1;
                    num1 = rand.nextInt(12) + 1;
                    num2 = rand.nextInt(12) + 1;

                    op = rand.nextInt(4);
                    op1 = rand.nextInt(4);

                    if (op1 <= op) { //FIRST OPERATOR PREFERENCE


                        if (op == 3) {
                            check = (float) num / num1;
                            rnd = Math.round(check);

                            while ((check != rnd) || (num1 == 0)) {
                                num = rand.nextInt(10) + 1;
                                num1 = rand.nextInt(10) + 1;
                                check = (float) num / num1;
                                rnd = Math.round(check);
                            }
                        }

                        switch (op) {
                            case 0:
                                first = num + num1;
                                break;
                            case 1:
                                first = num - num1;
                                break;
                            case 2:
                                first = num * num1;
                                break;
                            case 3:
                                first = num / num1;
                                break;
                        }

                        if (op1 == 3) {
                            check = (float) first / num2;
                            rnd = Math.round(check);

                            while (check != rnd) {
                                num2 = rand.nextInt(10) + 1;
                                check = (float) first / num2;
                                rnd = Math.round(check);
                            }
                        }

                        switch (op1) {
                            case 0:
                                result = first + num2;
                                break;
                            case 1:
                                result = first - num2;
                                break;
                            case 2:
                                result = first * num2;
                                break;
                            case 3:
                                result = first / num2;
                                break;
                        }
                    }

                    else if (op1 > op) //SECOND OPERATOR PREFERENCE
                    {

                        if (op1 == 3) {

                            check1 = (float) num1 / num2;
                            rnd1 = Math.round(check1);

                            while (check1 != rnd1) {
                                num1 = rand.nextInt(10) + 1;
                                num2 = rand.nextInt(10) + 1;
                                check1 = (float) num1 / num2;
                                rnd1 = Math.round(check1);
                            }
                        }


                        switch (op1) {
                            case 0:
                                first = num1 + num2;
                                break;
                            case 1:
                                first = num1 - num2;
                                break;
                            case 2:
                                first = num1 * num2;
                                break;
                            case 3:
                                first = num1 / num2;
                                break;
                        }

                        if (op == 3) {

                            check1 = (float) num / first;
                            rnd1 = Math.round(check1);

                            while (check1 != rnd1) {
                                num = rand.nextInt(10) + 1;
                                check1 = (float) num / first;
                                rnd1 = Math.round(check1);
                            }
                        }

                        switch (op) {
                            case 0:
                                result = num + first;
                                break;
                            case 1:
                                result = num - first;
                                break;
                            case 2:
                                result = num * first;
                                break;
                            case 3:
                                result = num / first;
                                break;
                        }
                    }

                } while (result<0);

                String myString = String.valueOf(num);
                String myString1 = String.valueOf(num1);
                String myString2 = String.valueOf(num2);

                t1.setText(myString + operations[op] + myString1 + operations[op1]+ myString2 + "=");

    }


}


