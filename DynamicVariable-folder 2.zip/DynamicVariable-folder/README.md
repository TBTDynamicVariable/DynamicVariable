# DynamicVariable
Project for EC327
This is a game project made by:
(Group members names)
for BU EC327 for fall 2018

Contents:
______________________________________________________________________________________________________________________
1. What it is:
  This is a fun, competitive math game to be played between you and your friends! You will be given a series of math equtions of various difficulty and be scored on how quickly you can solve them. Solve them as fast as possible for a high score.

2. Approach:
  This is an android application made through android studio. The app was coded in both native java and c++ using the android studio c/c++ jdk. 
  
3. Instructions:
  To install the game, simply download it off of this github directory, or from the android play store. The game will then prompt the user where they would like to navigate from there. The navigation options are a highscore leaderboard, playing the game, and viewing an instructions page. The game requires the user to input an integer answer input to the questions and then press enter. Each correct answer rewards the player with one point - A time limit of 1 minute 30 seconce will show who is the conquerer of basic arithmetic. 
  
4. Other stuff? probably
